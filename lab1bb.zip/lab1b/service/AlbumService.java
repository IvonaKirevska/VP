package mk.ukim.finki.lab1b.service;

import mk.ukim.finki.lab1b.model.Album;

import java.util.List;

public interface AlbumService {
    public List<Album> findAll();
}
